  FILE "libchdman-rs-test-data.bin" BINARY
    TRACK 01 MODE1/2352
      INDEX 01 00:00:00
  FILE "libchdman-rs-test-audio.bin" BINARY
    TRACK 02 AUDIO
      INDEX 01 00:00:00
